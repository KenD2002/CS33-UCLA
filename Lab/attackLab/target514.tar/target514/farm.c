/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned addval_281(unsigned x)
{
    return x + 3281031256U;
}

unsigned getval_117()
{
    return 3284633928U;
}

unsigned addval_254(unsigned x)
{
    return x + 2488845363U;
}

unsigned getval_479()
{
    return 2428995944U;
}

unsigned getval_338()
{
    return 2421687864U;
}

unsigned getval_236()
{
    return 2496104776U;
}

unsigned addval_111(unsigned x)
{
    return x + 2428995912U;
}

void setval_160(unsigned *p)
{
    *p = 2425376840U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

void setval_312(unsigned *p)
{
    *p = 3222850185U;
}

unsigned getval_299()
{
    return 3525364393U;
}

unsigned addval_341(unsigned x)
{
    return x + 3531921065U;
}

void setval_451(unsigned *p)
{
    *p = 3372799629U;
}

unsigned getval_343()
{
    return 3767093481U;
}

unsigned addval_282(unsigned x)
{
    return x + 3269495112U;
}

void setval_109(unsigned *p)
{
    *p = 3285617019U;
}

unsigned getval_200()
{
    return 3767097489U;
}

unsigned addval_337(unsigned x)
{
    return x + 3281043849U;
}

unsigned addval_408(unsigned x)
{
    return x + 3353381192U;
}

unsigned addval_303(unsigned x)
{
    return x + 3224945035U;
}

unsigned getval_128()
{
    return 3385115017U;
}

unsigned getval_382()
{
    return 3375942281U;
}

void setval_377(unsigned *p)
{
    *p = 3524843145U;
}

unsigned getval_217()
{
    return 3682912909U;
}

void setval_119(unsigned *p)
{
    *p = 3285584290U;
}

unsigned addval_274(unsigned x)
{
    return x + 3286272329U;
}

unsigned getval_304()
{
    return 3603527766U;
}

unsigned addval_480(unsigned x)
{
    return x + 3674786441U;
}

void setval_442(unsigned *p)
{
    *p = 3224945033U;
}

unsigned addval_456(unsigned x)
{
    return x + 2430634312U;
}

unsigned getval_449()
{
    return 3269495112U;
}

void setval_203(unsigned *p)
{
    *p = 2425667977U;
}

void setval_464(unsigned *p)
{
    *p = 3674789529U;
}

unsigned getval_395()
{
    return 3525367433U;
}

unsigned addval_245(unsigned x)
{
    return x + 3678980745U;
}

void setval_127(unsigned *p)
{
    *p = 3374891401U;
}

unsigned addval_105(unsigned x)
{
    return x + 1556597385U;
}

unsigned getval_436()
{
    return 3768141925U;
}

unsigned getval_454()
{
    return 3682910593U;
}

unsigned addval_331(unsigned x)
{
    return x + 3531915689U;
}

void setval_137(unsigned *p)
{
    *p = 3525364365U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
